<?php

namespace App\Controller;
use App\Service\MessageGenarator;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HelloController extends AbstractController
{


    /**
     * @Route("/yeni")
     * @param MessageGenarator $messageGenarator
     * @return Response

     */
    public function hello(MessageGenarator $messageGenarator){
        return $this->render("user.html.twig", [
            "name" => $messageGenarator->helloMessage()
        ]);
    }
}