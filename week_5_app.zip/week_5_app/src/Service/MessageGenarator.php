<?php

namespace App\Service;

use Symfony\Component\HttpFoundation\RequestStack;

class MessageGenarator
{

    private $requestStack;
    /**
     * @param RequestStack $requestStack
     */

        public function __construct( RequestStack $requestStack)
        {
            $this->requestStack = $requestStack;

        }

        public function helloMessage(): string
        {
            $requests = $this->requestStack->getCurrentRequest();

            $name = $requests->query->get("name", "Bilal");
            return $name;
        }



}